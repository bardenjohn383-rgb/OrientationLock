# 方向锁定 (OrientationLock)

一个 Xposed / LSPosed 模块：为**指定应用**屏蔽自动旋转，按应用锁定为竖屏 / 横屏等方向。

## 功能
- 按应用单独设置屏幕方向：锁定竖屏 / 锁定横屏 / 反向竖屏 / 反向横屏 / 跟随传感器（允许旋转）/ 跟随系统（不处理）。
- 拦截应用运行时的 `Activity#setRequestedOrientation`，并在 Activity 创建时强制方向，覆盖绝大多数应用（包括只在 AndroidManifest 里声明方向、依赖传感器旋转的应用）。

## 目录结构
```
OrientationLock/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/xposed_init          # Hook 入口类名
        ├── java/com/example/orientationlock/
        │   ├── MainHook.kt             # Hook 逻辑
        │   ├── MainActivity.kt         # 选应用 + 选方向的界面
        │   └── Config.kt               # 方向选项与配置
        └── res/...
```

## 构建
1. 用 Android Studio 打开本目录（会自动下载 Gradle 8.2 与依赖）。
2. 或命令行（需 JDK 17 + Android SDK）：
   ```bash
   # 本目录未带 gradle wrapper 二进制，先生成一次：
   gradle wrapper --gradle-version 8.2
   ./gradlew assembleRelease
   ```
   产物在 `app/build/outputs/apk/release/app-release.apk`。

## 安装与使用
1. 手机需已 Root，并安装 LSPosed（或旧版 EdXposed）。
2. 安装本模块 APK。
3. 打开 LSPosed → 模块 → 启用「方向锁定」。
4. 在 LSPosed 的**作用域**里勾选要控制的应用。
5. 打开「方向锁定」App，点击应用名，选择要锁定的方向。
6. 强制停止目标应用后重新打开（或直接重启手机）。

## 说明
- 配置存在模块内部，目标应用进程通过 `XSharedPreferences` 跨进程读取；改动方向后需**重启目标应用**才生效。
- 少数在底层自行实现旋转的应用（如部分游戏、视频全屏）可能不生效，属正常现象。
- 某些应用本身强制横屏 / 竖屏，被锁到相反方向时可能出现显示异常，请按需选择。
- 本机无需 Root 就无法运行此模块（LSPosed 依赖 Root）；仅源码交付，需在 PC 或能构建的环境打包 APK。
