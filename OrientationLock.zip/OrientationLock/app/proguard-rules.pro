# 默认不混淆即可；Hook 入口类名写在 assets/xposed_init，勿混淆。
-keep class com.example.orientationlock.MainHook { *; }
