package com.example.orientationlock

import android.content.pm.ActivityInfo

/**
 * 模块配置：可选屏幕方向、跨进程配置文件名。
 */
object Config {
    const val PREFS_NAME = "orientation_config"

    /** 模块自身包名，用于跨进程读取配置和排除自身。 */
    const val MODULE_PACKAGE = "com.example.orientationlock"

    /** 特殊值：表示未配置（勾选框未勾选），即不 Hook。 */
    const val UNSET = Int.MIN_VALUE

    /** 勾选时默认锁定的方向：竖屏。 */
    const val DEFAULT_ORIENTATION = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

    data class OrientationOption(val label: String, val value: Int)

    /** 可选方向（勾选后生效，点击卡片可在此选择）。 */
    val OPTIONS = listOf(
        OrientationOption("锁定竖屏", ActivityInfo.SCREEN_ORIENTATION_PORTRAIT),
        OrientationOption("锁定横屏", ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE),
        OrientationOption("反向竖屏", ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT),
        OrientationOption("反向横屏", ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE),
        OrientationOption("跟随传感器（允许旋转）", ActivityInfo.SCREEN_ORIENTATION_SENSOR),
    )
}
