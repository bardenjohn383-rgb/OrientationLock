package com.example.orientationlock

import android.content.pm.ActivityInfo

/**
 * 模块配置：可选的屏幕方向列表，以及跨进程配置的文件名。
 */
object Config {
    const val PREFS_NAME = "orientation_config"

    /** 模块自身包名，用于跨进程读取配置和排除自身。 */
    const val MODULE_PACKAGE = "com.example.orientationlock"

    /** 特殊值：表示「跟随系统，不处理」，即不 Hook。 */
    const val UNSET = Int.MIN_VALUE

    data class OrientationOption(val label: String, val value: Int)

    val OPTIONS = listOf(
        OrientationOption("跟随系统（不处理）", UNSET),
        OrientationOption("锁定竖屏", ActivityInfo.SCREEN_ORIENTATION_PORTRAIT),
        OrientationOption("锁定横屏", ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE),
        OrientationOption("反向竖屏", ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT),
        OrientationOption("反向横屏", ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE),
        OrientationOption("跟随传感器（允许旋转）", ActivityInfo.SCREEN_ORIENTATION_SENSOR),
    )
}
