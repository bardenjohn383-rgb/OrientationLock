package com.example.orientationlock

import android.app.Activity
import android.app.AlertDialog
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    private data class AppInfo(
        val packageName: String,
        val label: String,
        val icon: Drawable,
        val isSystem: Boolean
    )

    private val allApps = mutableListOf<AppInfo>()
    private val prefs by lazy { getSharedPreferences(Config.PREFS_NAME, MODE_PRIVATE) }

    private var showSystem = false
    private var configuredOnly = false
    private var query = ""

    private var visible = mutableListOf<AppInfo>()
    private lateinit var adapter: AppAdapter
    private lateinit var searchBox: EditText
    private lateinit var btnSystem: Button
    private lateinit var btnAll: Button
    private lateinit var btnConfigured: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        searchBox = findViewById(R.id.search_box)
        btnSystem = findViewById(R.id.btn_system)
        btnAll = findViewById(R.id.btn_all)
        btnConfigured = findViewById(R.id.btn_configured)
        val list = findViewById<ListView>(R.id.list)

        loadApps()
        adapter = AppAdapter()
        list.adapter = adapter

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                refresh()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        btnSystem.setOnClickListener {
            showSystem = !showSystem
            updateTabButtons()
            refresh()
        }
        btnAll.setOnClickListener {
            configuredOnly = false
            updateTabButtons()
            refresh()
        }
        btnConfigured.setOnClickListener {
            configuredOnly = true
            updateTabButtons()
            refresh()
        }

        updateTabButtons()
        refresh()
    }

    private fun updateTabButtons() {
        btnSystem.text = getString(if (showSystem) R.string.system_on else R.string.system_off)
        btnSystem.isSelected = showSystem
        btnAll.isSelected = !configuredOnly
        btnConfigured.isSelected = configuredOnly
    }

    /** 加载所有已安装应用，默认只显示用户应用（系统应用由按钮切换）。 */
    private fun loadApps() {
        val pm = packageManager
        allApps.clear()
        for (ai in pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
            if (ai.packageName == packageName) continue // 排除本模块自身
            allApps.add(
                AppInfo(
                    packageName = ai.packageName,
                    label = ai.loadLabel(pm).toString(),
                    icon = ai.loadIcon(pm),
                    isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                )
            )
        }
        allApps.sortBy { it.label.lowercase() }
    }

    private fun isConfigured(pkg: String): Boolean =
        prefs.getInt(pkg, Config.UNSET) != Config.UNSET

    private fun visibleApps(): List<AppInfo> = allApps
        .filter { showSystem || !it.isSystem }
        .filter { if (configuredOnly) isConfigured(it.packageName) else true }
        .filter {
            query.isBlank() ||
                it.label.contains(query, ignoreCase = true) ||
                it.packageName.contains(query, ignoreCase = true)
        }

    private fun refresh() {
        visible = visibleApps().toMutableList()
        adapter.notifyDataSetChanged()
    }

    private fun save(pkg: String, value: Int) {
        prefs.edit().putInt(pkg, value).commit()
        makePrefsWorldReadable()
    }

    /** 让目标应用进程（不同 UID）能通过 XSharedPreferences 读到配置。 */
    private fun makePrefsWorldReadable() {
        try {
            val f = File(applicationInfo.dataDir, "shared_prefs/${Config.PREFS_NAME}.xml")
            if (!f.exists()) return
            f.setReadable(true, false)
            f.parentFile?.setExecutable(true, false)
            f.parentFile?.setReadable(true, false)
            File(applicationInfo.dataDir).setExecutable(true, false)
        } catch (_: Throwable) {
        }
    }

    private fun showOrientationDialog(info: AppInfo) {
        val labels = Config.OPTIONS.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(info.label)
            .setItems(labels) { _, which ->
                save(info.packageName, Config.OPTIONS[which].value)
                refresh()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = visible.size
        override fun getItem(position: Int) = visible[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view = convertView ?: LayoutInflater.from(this@MainActivity)
                .inflate(R.layout.item_app, parent, false)
            val info = getItem(position)
            view.findViewById<ImageView>(R.id.icon).setImageDrawable(info.icon)
            view.findViewById<TextView>(R.id.label).text = info.label
            view.findViewById<TextView>(R.id.package_name).text = info.packageName

            val check = view.findViewById<CheckBox>(R.id.check)
            check.setOnCheckedChangeListener(null)
            check.isChecked = isConfigured(info.packageName)
            check.setOnCheckedChangeListener { _, checked ->
                save(info.packageName, if (checked) Config.DEFAULT_ORIENTATION else Config.UNSET)
                refresh()
            }

            // 点击卡片（非勾选框）选择方向
            view.setOnClickListener { showOrientationDialog(info) }
            return view
        }
    }
}
