package com.example.orientationlock

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    private data class AppInfo(
        val packageName: String,
        val label: String,
        val icon: Drawable
    )

    private val apps = mutableListOf<AppInfo>()
    private val prefs by lazy { getSharedPreferences(Config.PREFS_NAME, MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        loadApps()
        findViewById<ListView>(R.id.list).adapter = AppAdapter()
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val pkg = ri.activityInfo.packageName
            if (!seen.add(pkg)) continue
            apps.add(AppInfo(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm)))
        }
        apps.sortBy { it.label }
    }

    private fun currentIndex(pkg: String): Int {
        val v = prefs.getInt(pkg, Config.UNSET)
        val idx = Config.OPTIONS.indexOfFirst { it.value == v }
        return if (idx >= 0) idx else 0
    }

    private fun save(pkg: String, value: Int) {
        prefs.edit().putInt(pkg, value).commit()
        makePrefsWorldReadable()
    }

    /** 让目标进程（不同 UID）能通过 XSharedPreferences 读到配置。 */
    private fun makePrefsWorldReadable() {
        try {
            val f = File(applicationInfo.dataDir, "shared_prefs/${Config.PREFS_NAME}.xml")
            if (!f.exists()) return
            f.setReadable(true, false)
            f.parentFile?.setExecutable(true, false)
            f.parentFile?.setReadable(true, false)
            File(applicationInfo.dataDir).setExecutable(true, false)
        } catch (_: Throwable) {
        }
    }

    private fun showDialog(info: AppInfo, current: Int) {
        val labels = Config.OPTIONS.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(info.label)
            .setSingleChoiceItems(labels, current) { dialog, which ->
                save(info.packageName, Config.OPTIONS[which].value)
                (findViewById<ListView>(R.id.list).adapter as AppAdapter).notifyDataSetChanged()
                dialog.dismiss()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(position: Int) = apps[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view = convertView ?: LayoutInflater.from(this@MainActivity)
                .inflate(R.layout.item_app, parent, false)
            val info = apps[position]
            view.findViewById<ImageView>(R.id.icon).setImageDrawable(info.icon)
            view.findViewById<TextView>(R.id.label).text = info.label
            view.findViewById<TextView>(R.id.package_name).text = info.packageName
            view.findViewById<TextView>(R.id.current).text =
                Config.OPTIONS[currentIndex(info.packageName)].label
            view.setOnClickListener { showDialog(info, currentIndex(info.packageName)) }
            return view
        }
    }
}
