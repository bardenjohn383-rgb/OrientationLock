package com.example.orientationlock

import android.app.Activity
import android.os.Bundle
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * Xposed 入口：按包名读取配置，对配置过的应用强制锁定屏幕方向。
 */
class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // 不 Hook 本模块自身
        if (lpparam.packageName == Config.MODULE_PACKAGE) return

        // 跨进程读取模块 UI 保存的配置
        val prefs = XSharedPreferences(Config.MODULE_PACKAGE, Config.PREFS_NAME)
        prefs.reload()
        val orientation = prefs.getInt(lpparam.packageName, Config.UNSET)
        if (orientation == Config.UNSET) return

        installHooks(orientation)
    }

    private fun installHooks(orientation: Int) {
        // 1) 拦截应用在运行时主动设置的屏幕方向（例如视频类应用设 SENSOR / LANDSCAPE）
        XposedHelpers.findAndHookMethod(
            Activity::class.java,
            "setRequestedOrientation",
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    param.args[0] = orientation
                }
            }
        )

        // 2) 对只在 AndroidManifest 里声明方向、运行时不调用 setRequestedOrientation 的应用，
        //    在 Activity 创建完成后强制一次方向，覆盖传感器自动旋转。
        XposedHelpers.findAndHookMethod(
            Activity::class.java,
            "onCreate",
            Bundle::class.java,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val activity = param.thisObject as? Activity ?: return
                    try {
                        activity.requestedOrientation = orientation
                    } catch (_: Throwable) {
                        // 某些对话框/特殊 Activity 不支持设置方向，忽略即可
                    }
                }
            }
        )
    }
}
